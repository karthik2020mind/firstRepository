package com.mindtree.employee_management.services;

import java.util.List;

import com.mindtree.employee_management.exception.ServiceException;
import com.mindtree.employee_management.model.Employee;

public interface EmployeeService {

	Employee addEmployee(Employee employee);

	Employee getEmployeeById(int employeeId) throws ServiceException;

	List<Employee> getAllEmployees();

	String deleteEmployee(int employeeId) throws ServiceException;

}