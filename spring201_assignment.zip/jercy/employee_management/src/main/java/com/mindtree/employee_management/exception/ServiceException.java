package com.mindtree.employee_management.exception;

public class ServiceException extends EmployeeManagementException {

	public ServiceException() {
		super();
	}

	public ServiceException(String message) {
		super(message);
	}

}
