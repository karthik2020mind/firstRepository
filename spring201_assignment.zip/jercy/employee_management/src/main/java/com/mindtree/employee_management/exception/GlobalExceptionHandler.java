package com.mindtree.employee_management.exception;

import java.util.Date;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.context.request.WebRequest;
@ControllerAdvice
public class GlobalExceptionHandler {

	@ExceptionHandler(ControllerException.class)
	public ResponseEntity<Error> exceptionHandleMethod(ControllerException e, WebRequest request) {
		Error info = new Error(new Date(), "employee Id not Found", request.getDescription(false));
		return new ResponseEntity<Error>(info, HttpStatus.NOT_FOUND);
	}

	
}
