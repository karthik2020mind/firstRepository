
package com.mindtree.employee_management.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.mindtree.employee_management.exception.ControllerException;
import com.mindtree.employee_management.exception.ServiceException;
import com.mindtree.employee_management.model.Employee;
import com.mindtree.employee_management.services.EmployeeService;

@RestController
@RequestMapping(value = "/employeemanagement")
public class EmployeeController {

	@Autowired
	private EmployeeService service;

	@PostMapping(value = "/addEmployee")
	public ResponseEntity<Employee> addNewEmployee(@RequestBody Employee employee) {
		Employee emp = service.addEmployee(employee);
		return new ResponseEntity<Employee>(emp, HttpStatus.OK);
	}

	@GetMapping(value = "/getEmployeeById/{employeeId}")
	public ResponseEntity<Employee> getEmployeeById(@PathVariable int employeeId) throws ControllerException {
		Employee emp = null;
		try {
			emp = service.getEmployeeById(employeeId);
		} catch (ServiceException e) {
			throw new ControllerException(e.getMessage());
		}
		return new ResponseEntity<Employee>(emp, HttpStatus.OK);
	}

	@GetMapping(value = "/getAllEmployees")
	public ResponseEntity<List<Employee>> getAllEmployee() {
		List<Employee> employeeList = service.getAllEmployees();
		return new ResponseEntity<List<Employee>>(employeeList, HttpStatus.OK);
	}

	@DeleteMapping(value = "/deleteEmployee/{employeeId}")
	public ResponseEntity<String> deleteEmployee(@PathVariable int employeeId) throws ControllerException {
		String message;
		try {
			message = service.deleteEmployee(employeeId);
		} catch (ServiceException e) {
			throw new ControllerException(e.getMessage());

		}
		return new ResponseEntity<String>(message, HttpStatus.OK);
	}
}
