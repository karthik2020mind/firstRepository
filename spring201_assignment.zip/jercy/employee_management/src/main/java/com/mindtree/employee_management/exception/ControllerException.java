package com.mindtree.employee_management.exception;

public class ControllerException extends EmployeeManagementException {

	public ControllerException() {
		super();
	}

	public ControllerException(String message) {
		super(message);
	}

}
