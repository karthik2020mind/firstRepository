package com.mindtree.employee_management.exception;

public class EmployeeManagementException extends Exception {

	public EmployeeManagementException() {
	}

	public EmployeeManagementException(String message) {
		
	}

}
