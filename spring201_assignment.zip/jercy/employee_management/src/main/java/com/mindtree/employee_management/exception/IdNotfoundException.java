package com.mindtree.employee_management.exception;

public class IdNotfoundException extends RuntimeException{

	public IdNotfoundException() {
		super();
	}

	public IdNotfoundException(String message) {
		super(message);
	}

}
