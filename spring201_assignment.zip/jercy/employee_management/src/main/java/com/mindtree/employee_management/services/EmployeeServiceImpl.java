package com.mindtree.employee_management.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mindtree.employee_management.exception.IdNotfoundException;
import com.mindtree.employee_management.exception.ServiceException;
import com.mindtree.employee_management.model.Employee;
import com.mindtree.employee_management.repository.EmployeeRepository;

@Service
public class EmployeeServiceImpl implements EmployeeService {

	@Autowired
	private EmployeeRepository repository;

	@Override
	public Employee addEmployee(Employee employee) {
		return repository.save(employee);
	}

	@Override
	public Employee getEmployeeById(int employeeId) throws ServiceException {
		Employee emp = null;
		try {
			emp = repository.findById(employeeId).orElse(null);

			if (emp == null) {
				throw new IdNotfoundException("Employee Id Not Found");
			}
		} catch (IdNotfoundException e) {
			throw new ServiceException(e.getMessage());
		}
		return emp;
	}

	@Override
	public List<Employee> getAllEmployees() {
		return repository.findAll();
	}

	@Override
	public String deleteEmployee(int employeeId) throws ServiceException {
		try {
		repository.deleteById(employeeId);
		}
		catch (Exception e) {
			throw new ServiceException("Employee Id Not Found");
		}
		return "Employee " + employeeId + " deleted Successfully";
	}
}
