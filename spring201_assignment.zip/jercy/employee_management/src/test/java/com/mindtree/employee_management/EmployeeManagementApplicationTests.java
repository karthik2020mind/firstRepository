package com.mindtree.employee_management;

import org.junit.jupiter.api.Test;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import org.mockito.stubbing.Answer;
import org.springframework.boot.test.context.SpringBootTest;
import static org.junit.jupiter.api.Assertions.assertEquals;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.mock.mockito.MockBean;

import com.mindtree.employee_management.exception.ServiceException;
import com.mindtree.employee_management.model.Employee;
import com.mindtree.employee_management.repository.EmployeeRepository;
import com.mindtree.employee_management.services.EmployeeService;

import static org.mockito.Mockito.when;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.times;

import java.util.Optional;
import java.util.stream.Collectors;
import java.util.stream.Stream;
@SpringBootTest
@RunWith(MockitoJUnitRunner.class)
class EmployeeManagementApplicationTests {

	@Autowired
	private EmployeeService service;
	@MockBean
	private EmployeeRepository repository;

	@Autowired
	private EmployeeRepository rep;
	private Employee employee;

	
	@Test
	public void testingAddMethod() {
		employee = new Employee();
		employee.setEmployeeId(111);
		employee.setEmployeeName("karthik");
		employee.setEmployeeAge(22);
		employee.setEmployeeLocation("chennai");
		employee.setSalary(3000000);
		when(repository.save(employee)).thenReturn(employee);
		assertEquals(employee, service.addEmployee(employee));
		
	}
	
	@Test
	public void deleteTest() {
		Employee empl= new Employee(111, "raja", 23, "chennai", 500000);
		try {
			service.deleteEmployee(111);
		} catch (ServiceException e) {
			System.out.println("id not found");
		}
		verify(repository, times(1)).deleteById(111);
	}
	
	@Test
	public void getEmployeesTest() {
		when(repository.findAll()).thenReturn(Stream
				.of(new Employee(11, "karthik", 23, "bangalore", 300000),
						new Employee(232, "raja", 43, "london", 4000000))
				.collect(Collectors.toList()));
		assertEquals(2, service.getAllEmployees().size());

	}
	@Test
	public void getEmployeeById() {
		Employee empl= new Employee(1,"raja",22,"chennai",450000);
       System.out.println(empl.getEmployeeId());

	}

}
