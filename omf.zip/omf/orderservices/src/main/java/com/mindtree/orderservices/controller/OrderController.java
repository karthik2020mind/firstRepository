package com.mindtree.orderservices.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.mindtree.orderservices.feignservices.FeignClient;
import com.mindtree.orderservices.model.Order;
import com.mindtree.orderservices.modeldto.Food;
import com.mindtree.orderservices.service.OrderServiceImpl;
import com.mindtree.orderservices.service.UserServiceImpl;

import io.github.resilience4j.circuitbreaker.annotation.CircuitBreaker;

@RestController
@RequestMapping("/order")
public class OrderController {

	@Autowired
	private OrderServiceImpl orderService;
	@Autowired
	private UserServiceImpl userService;
	@Autowired
	private FeignClient feign;

	
	@PutMapping(value = "/updateOrder/{orderId}")
	public Order updateOrder(@PathVariable int orderId,@RequestBody Order order) {
		return orderService.updateOrder(orderId, order);
	}
	
	@DeleteMapping(value = "/cancelOrder/{userId}/{orderId}")
	public String cancelOreder(@PathVariable int userId,@PathVariable int orderId) {
		return userService.cancelOrder(userId, orderId);
	}
	
	@DeleteMapping(value = "/cancelOrd/{orderId}")
	public String cancelOreders(@PathVariable int orderId) {
		return orderService.cancelOrder(orderId);
	}
	

	@GetMapping(value = "/menucard/{restaurantId}")
	public List<Food> getFoodMenu(@PathVariable int restaurantId){
		return feign.getFoodMenu(restaurantId);
	}
	
}
