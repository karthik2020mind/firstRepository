package com.mindtree.orderservices.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.mindtree.orderservices.email.apidto.MailRequest;
import com.mindtree.orderservices.email.apidto.MailResponse;
import com.mindtree.orderservices.email.apiservice.EmailService;
import com.mindtree.orderservices.model.Order;
import com.mindtree.orderservices.model.User;
import com.mindtree.orderservices.service.UserServiceImpl;

@RestController
@RequestMapping("/user")
public class UserController {

	@Autowired
	private UserServiceImpl userservice;
	
	@PostMapping(value = "/createUser")
	public User createUser(@RequestBody User user) {
		
		return userservice.createUser(user);
		
	}
	
	@GetMapping(value = "/viewOrders/{userId}")
	public List<Order> viewOrders(@PathVariable int userId){
		return userservice.viewOrders(userId);
	}
	
	@Autowired
	private EmailService service;

	@PostMapping("/sendingEmail")
	public MailResponse sendEmail(@RequestBody MailRequest request) {
		Map<String, Object> model = new HashMap<>();
		model.put("Name", request.getName());
		model.put("location", request.getLocation());
		model.put("food", request.getFood());
		model.put("quantity", request.getQuantity());

		return service.sendEmail(request, model);
}}
