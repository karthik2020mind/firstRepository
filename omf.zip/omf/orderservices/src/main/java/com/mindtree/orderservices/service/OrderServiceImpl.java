package com.mindtree.orderservices.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mindtree.orderservices.model.Order;
import com.mindtree.orderservices.repository.OrderRepository;
import com.mindtree.orderservices.repository.UserRepository;

@Service
public class OrderServiceImpl {

	@Autowired
	private OrderRepository repository;
	
	public Order updateOrder(int id,Order order) {
		Order exist=repository.findById(id).orElse(null);
		exist.setQuantity(order.getQuantity());
		exist.setLocation(order.getLocation());
		return repository.save(exist);
	}
	
	public String cancelOrder(int id) {
		repository.deleteById(id);
		return "Order Cancelled Successfully";
	}
	
}
