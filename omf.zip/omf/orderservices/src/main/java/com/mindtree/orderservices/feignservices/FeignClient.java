package com.mindtree.orderservices.feignservices;

import java.util.List;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;

import com.mindtree.orderservices.modeldto.Food;

import io.github.resilience4j.circuitbreaker.annotation.CircuitBreaker;

@org.springframework.cloud.openfeign.FeignClient(name = "restaurant")
public interface FeignClient {

	
	 static final String ORDER_SERVICE = "orderService";

	@GetMapping(value = "/restaurant/getMenucard/{restaurantId}")
	public List<Food> getFoodMenu(@PathVariable int restaurantId);
	
	@PutMapping(value = "/restaurant/updateFoodStock/{foodId}/{updatedStock}")
	public void updateFoodStock(@PathVariable int foodId,@PathVariable int updatedStock);
	
	@GetMapping(value = "/restaurant/getFood/{foodId}")
	public Food getFood(@PathVariable int foodId);
	
	default String orderFallback() {
		return "failed";
	}
}
