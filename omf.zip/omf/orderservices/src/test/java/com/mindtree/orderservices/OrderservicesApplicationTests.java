package com.mindtree.orderservices;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OrderservicesApplicationTests {

	@Test
	void contextLoads() {
	}

}
