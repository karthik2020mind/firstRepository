package com.mindtree.restaurantservices.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mindtree.restaurantservices.model.Food;
import com.mindtree.restaurantservices.model.Restaurant;
import com.mindtree.restaurantservices.repository.FoodRepository;
import com.mindtree.restaurantservices.repository.RestaurantRepository;

@Service
public class RestaurantServiceImpl {

	@Autowired
	private RestaurantRepository repository;
	@Autowired
	private FoodRepository foodRepository;
	public Restaurant addRestaurant(Restaurant restaurant) {
		return repository.save(restaurant);
	}
	
	public List<Restaurant> getRestaurantByName(String name){
		return repository.getByName(name);
	}
	
	public List<Restaurant> getRestaurantByLocation(String location){
		return repository.getByLocation(location);
	}
	
	public List<Restaurant> getRestaurantByDistance(double distance){
		return repository.getByDistance(distance);
	}
	
	public List<Restaurant> getRestaurantByBudget(double budget){
		return repository.getByBudget(budget);
	}
	
	public List<Restaurant> getRestaurantByType(String type){
		return repository.getByType(type);
	}
	
	public List<Food> getMenuCard(int restaurantId){
		Restaurant restaurant=repository.findById(restaurantId).orElse(null);
		List<Food> menucard=restaurant.getFood();
		return menucard;
	}
	
	public void updateFoodStock(int foodId,int newStock) {
		foodRepository.updateStock(foodId, newStock);
	}
	
	public Food getFood(int foodId) {
		return foodRepository.findById(foodId).orElse(null);
	}
}
