package com.mindtree.restaurantservices.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.mindtree.restaurantservices.model.Food;
import com.mindtree.restaurantservices.model.Restaurant;
import com.mindtree.restaurantservices.services.RestaurantServiceImpl;

@RestController
@RequestMapping("/restaurant")
public class RestaurantController {

	@Autowired
	private RestaurantServiceImpl service;
	
	@PostMapping(value = "/addRestaurant")
	public Restaurant createRestaurant(@RequestBody Restaurant restaurant) {
		return service.addRestaurant(restaurant);
	}
	
	@GetMapping(value = "/searchByName/{name}")
	public List<Restaurant> searchByName(@PathVariable String name){
		return service.getRestaurantByName(name);
	}
	
	@GetMapping(value = "/searchByLocation/{location}")
	public List<Restaurant> searchByLocation(@PathVariable String location){
		return service.getRestaurantByName(location);
	}
	
	@GetMapping(value = "/searchByDistance/{distance}")
	public List<Restaurant> searchByDistance(@PathVariable double distance){
		return service.getRestaurantByDistance(distance);
	}
	
	@GetMapping(value = "/searchByBudget/{budget}")
	public List<Restaurant> searchByBudget(@PathVariable double budget){
		return service.getRestaurantByBudget(budget);
	}
	
	@GetMapping(value = "/searchByType/{type}")
	public List<Restaurant> searchType(@PathVariable String type){
		return service.getRestaurantByType(type);
		
	}
	
	@GetMapping(value = "/getMenucard/{restaurantId}")
	public List<Food> getMenuCard(@PathVariable int restaurantId){
		return service.getMenuCard(restaurantId);
	}
	
	@PutMapping(value = "/updateFoodStock/{foodId}/{newStock}")
	public void updateFoodStock(@PathVariable int foodId,@PathVariable int newStock) {
		service.updateFoodStock(foodId, newStock);
	}
	@GetMapping(value = "/getFood/{foodId}")
	public Food getFood(@PathVariable int foodId) {
		return service.getFood(foodId);
	}
}
