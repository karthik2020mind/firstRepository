package com.eurekaserver.eurekaexample;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EurekaexampleApplicationTests {

	@Test
	void contextLoads() {
	}

}
