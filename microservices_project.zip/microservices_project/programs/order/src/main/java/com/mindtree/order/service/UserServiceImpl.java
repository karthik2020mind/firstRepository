package com.mindtree.order.service;

import java.text.SimpleDateFormat;
import java.time.LocalTime;
import java.util.Date;
import java.util.List;

import javax.persistence.Entity;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mindtree.order.feignservices.FeignClient;
import com.mindtree.order.model.Order;
import com.mindtree.order.model.User;
import com.mindtree.order.modeldto.Food;
import com.mindtree.order.repository.OrderRepository;
import com.mindtree.order.repository.UserRepository;

@Service
public class UserServiceImpl implements UserService {

	@Autowired
	private UserRepository userrepository;
	@Autowired
	private OrderRepository op;
	@Autowired
	private FeignClient fp;
	@Override
	public User createUser(User user) {
		List<Order> order=user.getOrder();
		for(Order o:order) {
			 Date date = new Date();
		     SimpleDateFormat formatter = new SimpleDateFormat("dd/MM/yy");
		     String str = formatter.format(date);
		     LocalTime time=java.time.LocalTime.now();
		     String str1=time.toString();
		     o.setDate(str);
		     o.setTime(str1);
			Food f= fp.getFood(o.getFoodId());
			fp.updateFoodStock(f.getId(), (f.getStock()-o.getQuantity()));
			o.setTotalPrice(f.getPrice()*o.getQuantity());
		}
		return userrepository.save(user);
}
	@Override
	public List<Order> viewOrders(int id) {
		User user=userrepository.findById(id).orElse(null);
		List<Order> orders=user.getOrder();
		return orders;
	}
	
	@Override
	public String cancelOrder(int userId,int orderId) {
		User user=userrepository.findById(userId).orElse(null);
		
		List<Order> orders=user.getOrder();

		for(Order o:orders) {
			if(o.getOrderId()==orderId) {
				
				orders.remove(o);
			}
		}
		//user.setOrder(orders);
		 userrepository.save(user);
		 return "order cancelled";

	}
}