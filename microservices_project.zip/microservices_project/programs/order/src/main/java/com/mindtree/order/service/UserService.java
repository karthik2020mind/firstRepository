package com.mindtree.order.service;

import java.util.List;

import com.mindtree.order.model.Order;
import com.mindtree.order.model.User;

public interface UserService {

	User createUser(User user);

	List<Order> viewOrders(int id);

	String cancelOrder(int userId, int orderId);

}