package com.mindtree.restaurant.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.mindtree.restaurant.model.Food;
import com.mindtree.restaurant.model.Restaurant;
import com.mindtree.restaurant.services.RestaurantService;

@RestController
@RequestMapping("/restaurant")
public class RestaurantController {

	@Autowired
	private RestaurantService service;
	
	@PostMapping(value = "/createRestaurant")
	public Restaurant createRestaurant(@RequestBody Restaurant restaurant) {
		return service.addRestaurant(restaurant);
	}
	
	@GetMapping(value = "/searchRestaurantByName/{name}")
	public List<Restaurant> searchByName(@PathVariable String name){
		return service.getRestaurantByName(name);
	}
	
	@GetMapping(value = "/searchRestaurantByLocation/{location}")
	public List<Restaurant> searchByLocation(@PathVariable String location){
		return service.getRestaurantByName(location);
	}
	
	@GetMapping(value = "/searchRestaurantByDistance/{distance}")
	public List<Restaurant> searchByDistance(@PathVariable double distance){
		return service.getRestaurantByDistance(distance);
	}
	
	@GetMapping(value = "/searchRestaurantByBudget/{budget}")
	public List<Restaurant> searchByBudget(@PathVariable double budget){
		return service.getRestaurantByBudget(budget);
	}
	
	@GetMapping(value = "/searchRestaurantByType/{type}")
	public List<Restaurant> searchType(@PathVariable String type){
		return service.getRestaurantByType(type);
		
	}
	
	@GetMapping(value = "/getFoodMenucard/{restaurantId}")
	public List<Food> getMenuCard(@PathVariable int restaurantId){
		return service.getMenuCard(restaurantId);
	}
	
	@PutMapping(value = "/updateFoodStock/{foodId}/{newStock}")
	public void updateFoodStock(@PathVariable int foodId,@PathVariable int newStock) {
		service.updateFoodStock(foodId, newStock);
	}
	@GetMapping(value = "/getFood/{foodId}")
	public Food getFood(@PathVariable int foodId) {
		return service.getFood(foodId);
	}
}
