package com.mindtree.restaurant;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import org.hibernate.query.criteria.internal.expression.SearchedCaseExpression.WhenClause;
import org.junit.jupiter.api.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.junit4.SpringRunner;

import com.mindtree.restaurant.model.Food;
import com.mindtree.restaurant.model.Restaurant;
import com.mindtree.restaurant.repository.FoodRepository;
import com.mindtree.restaurant.repository.RestaurantRepository;
import com.mindtree.restaurant.services.RestaurantService;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.when;
@SpringBootTest
@RunWith(SpringRunner.class)
class RestaurantservicesApplicationTests {

	@MockBean
	RestaurantRepository restuarantRepos;
	@MockBean
	FoodRepository foodRepository;
	@Autowired
	RestaurantService res;
	@Test
	void add() {
		Restaurant restuarant = new Restaurant();
		Food food = new Food();
		food.setFoodName("pizza");
		food.setFoodType("nonveg");
		food.setPrice(120.00);
		food.setStock(30);
		List<Food> foods = new ArrayList<>();
		foods.add(food);
		restuarant.setId(1);
		restuarant.setFood(foods);
		restuarant.setBudget(230000.00);
		restuarant.setDistance(23.00);
		restuarant.setLocation("Chennai");
		restuarant.setRestaurantName("Chinese Restuarant");
		restuarant.setRestaurantType("chinese");		
		  when(restuarantRepos.save(restuarant)).thenReturn(restuarant);
		  assertEquals(restuarant,res.addRestaurant(restuarant));
		 
	}
	@Test
	void findByName() {
		when(restuarantRepos.getRestaurantByName("abc")).thenReturn(Stream
				.of(new Restaurant(1, "abc", "chennai", 30, 2000, "classic", null))
				.collect(Collectors.toList()));
		assertEquals(1, res.getRestaurantByName("abc").size());
	}
	@Test
	void findByLocation() {
		when(restuarantRepos.getRestaurantByLocation("chennai")).thenReturn(Stream
				.of(new Restaurant(1, "abc", "chennai", 30, 2000, "classic", null))
				.collect(Collectors.toList()));
		assertEquals(1, res.getRestaurantByLocation("chennai").size());
	}
	@Test
	void findByDistance() {
		when(restuarantRepos.getRestaurantByDistance(30)).thenReturn(Stream
				.of(new Restaurant(1, "abc", "chennai", 30, 2000, "classic", null))
				.collect(Collectors.toList()));
		assertEquals(1, res.getRestaurantByDistance(30).size());
	}
	@Test
	void findByBudget() {
		when(restuarantRepos.getRestaurantByBudget(2000)).thenReturn(Stream
				.of(new Restaurant(1, "abc", "chennai", 30, 2000, "classic", null))
				.collect(Collectors.toList()));
		assertEquals(1, res.getRestaurantByBudget(2000).size());
	}
	@Test
	void findByType() {
		when(restuarantRepos.getRestaurantByType("classic")).thenReturn(Stream
				.of(new Restaurant(1, "abc", "chennai", 30, 2000, "classic", null))
				.collect(Collectors.toList()));
		assertEquals(1, res.getRestaurantByType("classic").size());
	}
	
	@Test
	public void getAllRestuarant() {
		List<Restaurant> restuarants = restuarantRepos.findAll();
		for (Restaurant restaurant : restuarants) {
			System.out.println(restaurant.getRestaurantName());
		}
	}

	@Test
	public void updateRestuarantDetails() {
		if (restuarantRepos.existsById(5)) {
			Restaurant restaurant = restuarantRepos.findById(5).get();
			restaurant.setLocation("Banglore");
		}
	}

}
